extends CharacterBody2D

@export var speed = 60
@export var health = 3
@export var bounce_height = 4
@export var bounce_speed = 6

var player
var bounce_time = 0.0
var base_y

func _ready():
	add_to_group("enemy")
	player = get_tree().get_first_node_in_group("player")
	base_y = position.y

func _physics_process(delta):
	if player:
		var direction = (player.global_position - global_position).normalized()
		velocity = direction * speed
		move_and_slide()

	# zıplama efekti
	bounce_time += delta * bounce_speed
	position.y = base_y + sin(bounce_time) * bounce_height

func take_damage(amount):
	health -= amount
	if health <= 0:
		queue_free()
