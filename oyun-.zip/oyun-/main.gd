extends Node2D

@export var enemy_scene : PackedScene

@onready var player = $player

func _ready():
	randomize()

func _on_timer_timeout():
	var enemy = enemy_scene.instantiate()
	
	var spawn_radius = 500
	var angle = randf() * TAU
	
	var offset = Vector2(cos(angle), sin(angle)) * spawn_radius
	enemy.position = player.global_position + offset
	
	add_child(enemy)
